<script src="assets/js/core.js"></script>
</body>
</html>