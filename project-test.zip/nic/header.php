<!DOCTYPE html>
<html>
	<head>
		<title>Project test | Enquiry Form</title>
		<meta name="description" content="Project test Enquiry Form "/>
		<meta name="keywords" content="Enquiry Form, project test"/>
		<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap/5.2.1/css/bootstrap.min.css"/>
		<link rel="stylesheet" href="assets/css/style.css"/>
		<!-- javascript -->
		<script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
		<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/js/bootstrap.min.js"></script>
		<script src="assets/js/jquery.min.js"></script>
	</head>
<body>