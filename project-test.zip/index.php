<?php

require('nic/header.php');
include('nic/config_db.php');

if(isset($_POST['enquery-form'])){

// echo "<pre>"; print_r($_POST); die();


	$query = "INSERT INTO tbl_enquery_form(category, cource, specialization, work_status, qualification, budget, stydy_hours, matters_more, name, email, number, location, dob) VALUES ('".$_POST['category']."','".$_POST['cource']."','".$_POST['cource-emp']."','".$_POST['work-status']."','".$_POST['qualified']."','".$_POST['finacial-budget']."','".$_POST['study-hours']."','".$_POST['metter-more']."','".$_POST['user-name']."','".$_POST['user-email']."','".$_POST['user-number']."','".$_POST['select-city']."','".$_POST['date-birth']."')";

	if(mysqli_query($conn, $query)){

		$message = "Your Query Successfully submitted.";
	}
}

?>
<div class="container-fluid">
	<div class="row">
		<section class="top-area"></section>
		<section class="main-container">
			<div class="container">
				<div class="row py-5">
					<div class="col-sm-2"></div>
					<div class="col-sm-8 text-center">
						<h2>Counselling</h2>
						<p>We ease your biggest doubts with personalized Video Counselling from our Curated Experts and Answers from the student community</p>
					</div>
					<div class="col-sm-2"></div>
				</div>
				<div class="row pb-5">
					<div class="col-sm-6">
						<img class="counseling-img" src="assets/img/counseling.png" alt="counseling">
					</div>
					<div class="col-sm-6 px-5">
						<div class="form-container shadow p-4 mb-4 bg-white rounded">
							<h4 class="exp-counselling">
								<img class="exp-icon" src="assets/img/expert-councling.svg" alt="Expert Counselling">
								<span>Expert Counselling</span>
							</h4>
							<p class="text-left">Personalized Video Counselling from Curated Experts on Exams, Courses, Colleges and Career selection on our App</p>
							<p class="text-left mb-0"><a class="start-now-button" href="https://play.google.com/store/apps/details?id=org.careers.mobile&referrer=utm_source%3Dcareers360-site%26utm_medium%3Dstart-now-button%26utm_campaign%3Dcounselling-section_c360-home">START NOW <span class="right-icon"><i class="fa fa-angle-right"></i></span></a></p>
						</div>
						<div class="form-container shadow p-4 mb-4 bg-white rounded">
							<h4 class="exp-counselling">
								<img class="exp-icon" src="assets/img/faq-qna.svg" alt="Expert Counselling">
								<span>QnA</span>
							</h4>
							<p class="text-left">1 Million+ Questions answered by the student community within 24 hours each</p>
							<p class="text-left mb-0"><a class="start-now-button" href="javascript:void(0);" data-toggle="modal" data-target="#askQuestion" rel="askQuestion">ASK NOW <span class="right-icon"><i class="fa fa-angle-right"></i></span></a>&nbsp;&nbsp;<a class="start-now-button btn-two" href="https://www.careers360.com/qna">QNA <span class="right-icon"><i class="fa fa-angle-right"></i></span></a></p>
						</div>
						<div class="form-container shadow p-4 mb-3 bg-white rounded">

							<?php if(!empty($message)){?>
							<h4 class="text-center" style="color:green;"><?php echo $message; ?></h4>
							<?php }else{?>
							<h4 class="text-center">Get Best Online University in 2 mins</h4>
							<?php } ?>
							<div class="progress-bars">
								<div class="step">
									<p> </p>
									<div class="bullet">
										<span>1</span>
									</div>
									<div class="check fas fa-check"></div>
								</div>
								<div class="step">
									<p> </p>
									<div class="bullet">
										<span>2</span>
									</div>
									<div class="check fas fa-check"></div>
								</div>
								<div class="step">
									<p> </p>
									<div class="bullet">
										<span>3</span>
									</div>
									<div class="check fas fa-check"></div>
								</div>
								<div class="step">
									<p> </p>
									<div class="bullet">
										<span>4</span>
									</div>
									<div class="check fas fa-check"></div>
								</div>
								<div class="step">
									<p> </p>
									<div class="bullet">
										<span>5</span>
									</div>
									<div class="check fas fa-check"></div>
								</div>
								<div class="step">
									<p> </p>
									<div class="bullet">
										<span>6</span>
									</div>
									<div class="check fas fa-check"></div>
								</div>
								<div class="step">
									<p> </p>
									<div class="bullet">
										<span>7</span>
									</div>
									<div class="check fas fa-check"></div>
								</div>
							</div>
							<div class="form-outer">
								<form method="post">
									<div class="page slide-page"> 
										<div class="title">Select Distance & Online Course</div>
										<div class="form-check">
											<input class="form-check-input d-none category" type="radio" value="Online Master's Programs" name="category" id="expRadios1" required="">
											<label class="form-check-label" for="expRadios1">Online Master's Programs</label>
										</div>
										<div class="form-check">
											<input class="form-check-input d-none category" type="radio" value="Online Bachelors Programs" name="category" id="expRadios2" required="">
											<label class="form-check-label" for="expRadios2">Online Bachelor's Programs</label>
										</div>
										<div class="form-check">
											<input class="form-check-input d-none category" type="radio" value="Online Diploma Certificate Programs" name="category" id="expRadios3" required="">
											<label class="form-check-label" for="expRadios3">Online Diploma &amp; Certificate Programs</label>
										</div>
										<div class="form-check">
											<input class="form-check-input d-none category" type="radio" value="Study Abroad" name="category" id="expRadios4" required="">
											<label class="form-check-label" for="expRadios4">Study Abroad</label>
										</div><br><br>
										
										<div class="field">
											<button class="firstNext next" id="getSelectedCource">Next</button>
										</div>
									</div>

									<div class="page">
										<div class="title">Select Distance & Online Course</div>
										<div id="selectedCource"></div>
											<br><br>
										<div class="field btns">
											<button class="prev-1 prev">Previous</button>
											<button class="next-1 next">Next</button>
										</div>
									</div>
									
									<div class="page">
										<div class="title">Select Specialization</div>
										
										<div class="field">
											<select name="cource-emp" class="form-select" required>
												<option>Select</option>
												<option>MBA General</option>
												<option>HR</option>
												<option>Finance</option>
												<option>Marketing</option>
												<option>General</option>
												<option>System And Operations</option>
												<option>Marketing And Finance</option>
												<option>Marketing And HR</option>
												<option>Information Technology</option>
												<option>Logistics And Supply Chain</option>
												
											</select>
										</div><br>
								
										<div class="field btns">
											<button class="prev-2 prev">Previous</button>
											<button class="next-2 next">Next</button>
										</div>
									</div>
									
									<div class="page">
										<div class="title">Are you Currently Working ?</div>
										
										<div class="form-check" style="display:unset;">
											<input class="form-check-input d-none category" type="radio" value="Yes" name="work-status" id="wkRadios1" required="">
											<label class="form-check-label" for="wkRadios1">Yes</label>
										</div>
										<div class="form-check" style="display:unset;">
											<input class="form-check-input d-none category" type="radio" value="No" name="work-status" id="wkRadios2" required="">
											<label class="form-check-label" for="wkRadios2">No</label>
										</div><br><br>


										<div class="field btns">
											<button class="prev-3 prev">Previous</button>
											<button class="next-3 next">Next</button>
										</div>
									</div>

									<div class="page">
										<div class="title">Your Highest Qualification?</div>
										
										<div class="form-check" style="display:unset;">
											<input class="form-check-input d-none category" type="radio" value="College Graduate" name="qualified" id="qfRadios0" required="">
											<label class="form-check-label" for="qfRadios0">College Graduate</label>
										</div>
										<div class="form-check" style="display:unset;">
											<input class="form-check-input d-none category" type="radio" value="Completed 12th" name="qualified" id="qfRadios1" required="">
											<label class="form-check-label" for="qfRadios1">Completed 12th</label>
										</div>
										<div class="form-check" style="display:unset;">
											<input class="form-check-input d-none category" type="radio" value="Completed 10th" name="qualified" id="qfRadios2" required="">
											<label class="form-check-label" for="qfRadios2">Completed 10th</label>
										</div>
										<div class="form-check" style="display:unset;">
											<input class="form-check-input d-none category" type="radio" value="Diploma Holder" name="qualified" id="qfRadios3" required="">
											<label class="form-check-label" for="qfRadios3">Diploma Holder</label>
										</div><br>
										<div class="form-check" style="display:unset;">
											<input class="form-check-input d-none category" type="radio" value="ITI" name="qualified" id="qfRadios4" required="">
											<label class="form-check-label" for="qfRadios4">ITI</label>
										</div><br><br>

										<div class="field btns">
											<button class="prev-4 prev">Previous</button>
											<button class="next-4 next">Next</button>
										</div>
									</div>


									<div class="page">
										<div class="title">Select Your Budget Options ?</div>
										
										<div class="form-check" style="display:unset;">
											<input class="form-check-input d-none category" type="radio" value="Less than 60,000" name="finacial-budget" id="fbRadios1" required="">
											<label class="form-check-label" for="fbRadios1">Less than 60,000</label>
										</div>
										<div class="form-check" style="display:unset;">
											<input class="form-check-input d-none category" type="radio" value="60,000 to 1 lac" name="finacial-budget" id="fbRadios2" required="">
											<label class="form-check-label" for="fbRadios2">60,000 to 1 lac</label>
										</div><br>
										<div class="form-check" style="display:unset;">
											<input class="form-check-input d-none category" type="radio" value="1 lac to 1.9 lac" name="finacial-budget" id="fbRadios3" required="">
											<label class="form-check-label" for="fbRadios3">1 lac to 1.9 lac</label>
										</div>
										<div class="form-check" style="display:unset;">
											<input class="form-check-input d-none category" type="radio" value="2 lac to 3.5 lac" name="finacial-budget" id="fbRadios4" required="">
											<label class="form-check-label" for="fbRadios4">2 lac to 3.5 lac</label>
										</div><br>
										<div class="form-check" style="display:unset;">
											<input class="form-check-input d-none category" type="radio" value="3.6 lac +" name="finacial-budget" id="fbRadios5" required="">
											<label class="form-check-label" for="fbRadios5">3.6 lac +</label>
										</div><br><br>

										<div class="field btns">
											<button class="prev-5 prev">Previous</button>
											<button class="next-5 next">Next</button>
										</div>
									</div>


									<div class="page">
										<div class="title">How many Study Hours can you Dedicate on the Weekly Basis?</div>
										
										<div class="form-check" style="display:unset;">
											<input class="form-check-input d-none category" type="radio" value="2-4 Hours" name="study-hours" id="shRadios1" required="">
											<label class="form-check-label" for="shRadios1">2-4 Hours</label>
										</div>
										<div class="form-check" style="display:unset;">
											<input class="form-check-input d-none category" type="radio" value="4-8 Hours" name="study-hours" id="shRadios2" required="">
											<label class="form-check-label" for="shRadios2">4-8 Hours</label>
										</div>
										<div class="form-check" style="display:unset;">
											<input class="form-check-input d-none category" type="radio" value="8-16 Hours" name="study-hours" id="shRadios3" required="">
											<label class="form-check-label" for="shRadios3">8-16 Hours</label>
										</div><br>
										<div class="form-check" style="display:unset;">
											<input class="form-check-input d-none category" type="radio" value="16+ Hours" name="study-hours" id="shRadios4" required="">
											<label class="form-check-label" for="shRadios4">16+ Hours</label>
										</div><br><br>

										<div class="field btns">
											<button class="prev-6 prev">Previous</button>
											<button class="next-6 next">Next</button>
										</div>
									</div>



									<div class="page">
										<div class="title">What matters to you more?</div>
										
										<div class="form-check">
											<input class="form-check-input d-none category" type="radio" value="The Right University +Right Course" name="metter-more" id="mRadios1" required="">
											<label class="form-check-label" for="mRadios1">The Right University +Right Course</label>
										</div>
										<div class="form-check">
											<input class="form-check-input d-none category" type="radio" value="Less Fee Structure" name="metter-more" id="mRadios2" required="">
											<label class="form-check-label" for="mRadios2">Less Fee Structure</label>
										</div>
										<div class="form-check">
											<input class="form-check-input d-none category" type="radio" value="8-16 Hours" name="metter-more" id="mRadios3" required="">
											<label class="form-check-label" for="mRadios3">I only care about the degree</label>
										</div><br><br>

										<div class="field btns">
											<button class="prev-7 prev">Previous</button>
											<button class="next-7 next">Next</button>
										</div>
									</div>


									<div class="page">
										<div class="title">Select Best University</div>
										<div class="field">
											<input type="text" name="user-name" placeholder="Enter Name" required/>
										</div>
										<div class="field">
											<input type="email" name="user-email" placeholder="Enter Email" required/>
										</div>
										<div class="field">
											<input type="number" name="user-number" placeholder="Enter Number" required/>
										</div>
										<div class="field">
											<select name="select-city" class="form-select">
												<option value="Delhi">Delhi</option>
                                              <option value="Uttar Pradesh">Uttar Pradesh</option>
                                              <option value="Uttarakhand">Uttarakhand</option>
                                              <option value="West Bengal">West Bengal</option>
                                              <option value="Punjab">Punjab</option>
                                              <option value="Rajasthan">Rajasthan</option>
                                              <option value="Sikkim">Sikkim</option>
                                              <option value="Tamil Nadu">Tamil Nadu</option>
                                              <option value="Telangana">Telangana</option>
                                              <option value="Tripura">Tripura</option>
                                              <option value="Andhra Pradesh">Andhra Pradesh</option>
                                              <option value="Arunachal Pradesh">Arunachal Pradesh</option>
                                              <option value="Assam">Assam</option>
                                              <option value="Bihar">Bihar</option>
                                              <option value="Chandigarh">Chandigarh</option>
                                              <option value="Chhattisgarh">Chhattisgarh</option>
                                              <option value="Goa">Goa</option>
                                              <option value="Gujarat">Gujarat</option>
                                              <option value="Haryana">Haryana</option>
                                              <option value="Himachal Pradesh">Himachal Pradesh</option>
                                              <option value="Jammu &amp; Kashmir">Jammu &amp; Kashmir</option>
                                              <option value="Jharkhand">Jharkhand</option>
                                              <option value="Karnataka">Karnataka</option>
                                              <option value="Kerala">Kerala</option>
                                              <option value="Lakshadweep">Lakshadweep</option>
                                              <option value="Madhya Pradesh">Madhya Pradesh</option>
                                              <option value="Maharashtra">Maharashtra</option>
                                              <option value="Manipur">Manipur</option>
                                              <option value="Meghalaya">Meghalaya</option>
                                              <option value="Mizoram">Mizoram</option>
                                              <option value="Nagaland">Nagaland</option>
                                              <option value="Orissa">Orissa</option>
                                              <option value="Puducherry">Puducherry</option>
                                              <option value="Andaman &amp; Nicobar Islands">Andaman &amp; Nicobar Islands</option>
                                              <option value="Dadra and Nagar Haveli">Dadra and Nagar Haveli</option>
                                              <option value="Daman and Diu">Daman and Diu</option>
                                              <option value="Ladakh">Ladakh</option>
											</select>
										</div><br>

										<div class="field">
											<div class="label">Date Of Birth:</div>
											<input type="date" name="date-birth" required/>
										</div><br>

										<div class="field btns">
											<button class="prev-7 prev">Previous</button>
											<button type="submit" name="enquery-form" class="submit">Submit</button>
										</div>
									</div>
								</form>
								<marquee class="suggest-marquee">5,00,000+ Students received their right university from this AI powered tool.</marquee>
							</div>
						</div>
					</div>
				</div>
			</div>
		</section>
		<section class="bottom-area"></section>
	</div>
</div>
<div class="modal fade show" id="askQuestion" tabindex="-1" role="dialog" aria-labelledby="myModalLabelOne" style="display: none;" aria-modal="true">
	<div class="modal-dialog" style="margin:15% auto;" role="document">
		<div class="modal-content">
			<form method="post">
				<div class="modal-header text-center">
					<h4 class="modal-title w-100 font-weight-bold">Ask your Question</h4>
					<span class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">×</span></span>
				</div>
				<div class="modal-body mx-3">
					<p class="tag-line">1 Million+ Questions answered | Get answers within 24 hours</p>
					<div class="md-form mb-2">
						<textarea class="form-control validate" id="askyourqustions" name="askyourqustions" row="5" placeholder="Ask your question about college, exam, career and other related topics, try to be as detailed as possible."></textarea>
					</div>
					<div class="captcha">
						<img src="assets/img/captch.JPG" alt="captch">
					</div>
					<div id="errorMessage"></div>
				</div>
				<div class="modal-footer d-flex justify-content-center">
					<button type="button" onclick="getaskQuestions();"  class="btn btn-post btn-sm" >Post</button>
				</div>
			</form>
		</div>
	</div>
</div>

<?php require('nic/footer.php'); ?>
