-- phpMyAdmin SQL Dump
-- version 4.8.0.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Sep 29, 2022 at 04:10 PM
-- Server version: 10.1.32-MariaDB
-- PHP Version: 5.6.36

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `project_test`
--

-- --------------------------------------------------------

--
-- Table structure for table `ask_questions`
--

CREATE TABLE `ask_questions` (
  `id` int(11) NOT NULL,
  `user_id` varchar(11) NOT NULL,
  `questions` varchar(500) NOT NULL,
  `datetime` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `ask_questions`
--

INSERT INTO `ask_questions` (`id`, `user_id`, `questions`, `datetime`) VALUES
(2, '', 'We ease your biggest doubts with personalized Video Counselling from our Curated Experts and Answers from the student community', '2022-09-29 11:42:53'),
(8, '', 'Ask your Question', '2022-09-29 13:16:29'),
(9, '', 'Testing FAQ form', '2022-09-29 19:35:20');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_enquery_form`
--

CREATE TABLE `tbl_enquery_form` (
  `id` int(11) NOT NULL,
  `category` varchar(100) NOT NULL,
  `cource` varchar(100) NOT NULL,
  `specialization` varchar(100) NOT NULL,
  `work_status` varchar(100) NOT NULL,
  `qualification` varchar(100) NOT NULL,
  `budget` varchar(100) NOT NULL,
  `stydy_hours` varchar(100) NOT NULL,
  `matters_more` varchar(100) NOT NULL,
  `name` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `number` varchar(100) NOT NULL,
  `location` varchar(100) NOT NULL,
  `dob` varchar(100) NOT NULL,
  `status` int(2) NOT NULL DEFAULT '1',
  `datetime` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_enquery_form`
--

INSERT INTO `tbl_enquery_form` (`id`, `category`, `cource`, `specialization`, `work_status`, `qualification`, `budget`, `stydy_hours`, `matters_more`, `name`, `email`, `number`, `location`, `dob`, `status`, `datetime`) VALUES
(1, 'Online Bachelors Programs', 'M.Tech', 'System And Operations', 'No', 'Diploma Holder', '2 lac to 3.5 lac', '4-8 Hours', '8-16 Hours', 'aniket Kumar', 'aniketdeveloper08@gmail.com', '9555924857', 'Delhi', '1994-07-06', 1, '2022-09-15 01:46:09'),
(3, 'Online Bachelors Programs', 'Executive MBA 1 Year', 'Marketing And Finance', 'Yes', 'Completed 12th', '60,000 to 1 lac', '4-8 Hours', 'The Right University +Right Course', 'Aniket Kumar', 'aniket@gmail.com', '9555924857', 'Haryana', '2022-09-21', 1, '2022-09-27 16:09:25'),
(4, 'Online Bachelors Programs', 'MCA', 'General', 'Yes', 'College Graduate', 'Less than 60,000', '8-16 Hours', 'Less Fee Structure', 'Aniket developer', 'aniket@gmail.com', '955948278', 'Delhi', '2022-09-23', 1, '2022-09-27 16:51:16'),
(5, 'Online Bachelors Programs', 'B Tech', 'General', 'Yes', 'Completed 12th', '60,000 to 1 lac', '8-16 Hours', 'The Right University +Right Course', 'Ramesh', 'ramesh@gmail.com', '9555924857', 'Bihar', '2022-09-29', 1, '2022-09-29 19:23:20'),
(6, 'Online Bachelors Programs', 'BBA', 'Marketing And HR', 'Yes', 'Completed 12th', '3.6 lac +', '16+ Hours', 'Less Fee Structure', 'Uday bhan', 'uday@gmail.com', '9555924852', 'Assam', '2022-09-20', 1, '2022-09-29 19:36:44');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `ask_questions`
--
ALTER TABLE `ask_questions`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_enquery_form`
--
ALTER TABLE `tbl_enquery_form`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `ask_questions`
--
ALTER TABLE `ask_questions`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `tbl_enquery_form`
--
ALTER TABLE `tbl_enquery_form`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
