<!DOCTYPE html>
<html>
	<head>
		<title>Project test | Enquiry Form</title>
		<meta name="description" content="Project test Enquiry Form "/>
		<meta name="keywords" content="Enquiry Form, project test"/>
		<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css">
		<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap/5.2.1/css/bootstrap.min.css"/>
		 <link rel="stylesheet" href="assets/css/style.css"/>
	</head>
<body>