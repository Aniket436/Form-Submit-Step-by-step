<?php

require('nic/header.php');
include('nic/config_db.php');

?>
<div class="container-fluid">
	<div class="row">
		<section class="top-area"></section>
		<section class="main-container">
			<div class="container">
				<div class="row py-5">
					<div class="col-sm-2"></div>
					<div class="col-sm-8 text-center">
						<h2>Counselling</h2>
						<p>We ease your biggest doubts with personalized Video Counselling from our Curated Experts and Answers from the student community</p>
					</div>
					<div class="col-sm-2"></div>
				</div>
				<div class="row pb-5">
					<div class="col-sm-6">
						<img class="counseling-img" src="assets/img/counseling.png" alt="counseling">
					</div>
					<div class="col-sm-6 px-5">
						<div class="form-container shadow p-4 mb-3 bg-white rounded">
							<h4 class="text-center">Get Best Online University in 2 mins</h4>
							<div class="progress-bars">
								<div class="step">
									<p> </p>
									<div class="bullet">
										<span>1</span>
									</div>
									<div class="check fas fa-check"></div>
								</div>
								<div class="step">
									<p> </p>
									<div class="bullet">
										<span>2</span>
									</div>
									<div class="check fas fa-check"></div>
								</div>
								<div class="step">
									<p> </p>
									<div class="bullet">
										<span>3</span>
									</div>
									<div class="check fas fa-check"></div>
								</div>
								<div class="step">
									<p> </p>
									<div class="bullet">
										<span>4</span>
									</div>
									<div class="check fas fa-check"></div>
								</div>
								<div class="step">
									<p> </p>
									<div class="bullet">
										<span>5</span>
									</div>
									<div class="check fas fa-check"></div>
								</div>
								<div class="step">
									<p> </p>
									<div class="bullet">
										<span>6</span>
									</div>
									<div class="check fas fa-check"></div>
								</div>
							</div>
							<div class="form-outer">
								<form action="#">
									<div class="page slide-page">
										<div class="title">Select Distance & Online Course</div>
										<div class="form-check">
											<input class="form-check-input d-none category" type="radio" value="online-distance-pg-course" name="category" id="expRadios1" required="">
											<label class="form-check-label" for="expRadios1">Online Master's Programs</label>
										</div>
										<div class="form-check">
											<input class="form-check-input d-none category" type="radio" value="online-distance-pg-course" name="category" id="expRadios2" required="">
											<label class="form-check-label" for="expRadios2">Online Bachelor's Programs</label>
										</div>
										<div class="form-check">
											<input class="form-check-input d-none category" type="radio" value="online-distance-pg-course" name="category" id="expRadios3" required="">
											<label class="form-check-label" for="expRadios3">Online Diploma &amp; Certificate Programs</label>
										</div>
										<div class="form-check">
											<input class="form-check-input d-none category" type="radio" value="online-distance-pg-course" name="category" id="expRadios4" required="">
											<label class="form-check-label" for="expRadios4">Study Abroad</label>
										</div>
										
										<div class="field">
											<button class="firstNext next">Next</button>
										</div>
									</div>

									<div class="page">
										<div class="title">Contact Info:</div>
										<div class="field">
											<div class="label">Email Address</div>
											<input type="text" required />
										</div>
										<div class="field">
											<div class="label">Phone Number</div>
											<input type="Number" required />
										</div>
										<div class="field btns">
											<button class="prev-1 prev">Previous</button>
											<button class="next-1 next">Next</button>
										</div>
									</div>
									
									<div class="page">
										<div class="title">Contact Info 2:</div>
										<div class="field">
											<div class="label">Email Address</div>
											<input type="text" required />
										</div>
										<div class="field">
											<div class="label">Phone Number</div>
											<input type="Number" required />
										</div>
										<div class="field btns">
											<button class="prev-2 prev">Previous</button>
											<button class="next-2 next">Next</button>
										</div>
									</div>
									
									<div class="page">
										<div class="title">Contact Info 3:</div>
										<div class="field">
											<div class="label">Email Address</div>
											<input type="text" required />
										</div>
										<div class="field">
											<div class="label">Phone Number</div>
											<input type="Number" required />
										</div>
										<div class="field btns">
											<button class="prev-3 prev">Previous</button>
											<button class="next-3 next">Next</button>
										</div>
									</div>

									<div class="page">
										<div class="title">Date of Birth:</div>
										<div class="field">
											<div class="label">Date</div>
											<input type="text" required />
										</div>
										<div class="field">
											<div class="label">Gender</div>
											<select required>
												<option>Male</option>
												<option>Female</option>
												<option>Other</option>
											</select>
										</div>
										<div class="field btns">
											<button class="prev-4 prev">Previous</button>
											<button class="next-4 next">Next</button>
										</div>
									</div>

									<div class="page">
										<div class="title">Login Details:</div>
										<div class="field">
											<div class="label">Username</div>
											<input type="text" required />
										</div>
										<div class="field">
											<div class="label">Password</div>
											<input type="password" required />
										</div>
										<div class="field btns">
											<button class="prev-5 prev">Previous</button>
											<button class="submit">Submit</button>
										</div>
									</div>
								</form>
							</div>
						</div>
					</div>
				</div>
			</div>
		</section>
		<section class="bottom-area"></section>
	</div>
</div>
<script>
initMultiStepForm();
function initMultiStepForm() {
    const progressNumber = document.querySelectorAll(".step").length;
    const slidePage = document.querySelector(".slide-page");
    const submitBtn = document.querySelector(".submit");
    const progressText = document.querySelectorAll(".step p");
    const progressCheck = document.querySelectorAll(".step .check");
    const bullet = document.querySelectorAll(".step .bullet");
    const pages = document.querySelectorAll(".page");
    const nextButtons = document.querySelectorAll(".next");
    const prevButtons = document.querySelectorAll(".prev");
    const stepsNumber = pages.length;
    if (progressNumber !== stepsNumber) {
        console.warn(
            "Error, number of steps in progress bar do not match number of pages"
        );
    }
    document.documentElement.style.setProperty("--stepNumber", stepsNumber);
    let current = 1;
    for (let i = 0; i < nextButtons.length; i++) {
        nextButtons[i].addEventListener("click", function (event) {
            event.preventDefault();

            inputsValid = validateInputs(this);
            // inputsValid = true;

            if (inputsValid) {
                slidePage.style.marginLeft = `-${
                    (100 / stepsNumber) * current
                }%`;
                bullet[current - 1].classList.add("active");
                progressCheck[current - 1].classList.add("active");
                progressText[current - 1].classList.add("active");
                current += 1;
            }
        });
    }
    for (let i = 0; i < prevButtons.length; i++) {
        prevButtons[i].addEventListener("click", function (event) {
            event.preventDefault();
            slidePage.style.marginLeft = `-${
                (100 / stepsNumber) * (current - 2)
            }%`;
            bullet[current - 2].classList.remove("active");
            progressCheck[current - 2].classList.remove("active");
            progressText[current - 2].classList.remove("active");
            current -= 1;
        });
    }
    submitBtn.addEventListener("click", function () {
        bullet[current - 1].classList.add("active");
        progressCheck[current - 1].classList.add("active");
        progressText[current - 1].classList.add("active");
        current += 1;
        setTimeout(function () {
            alert("Your Form Successfully Signed up");
            location.reload();
        }, 800);
    });

    function validateInputs(ths) {
        let inputsValid = true;

        const inputs =
            ths.parentElement.parentElement.querySelectorAll("input");
        for (let i = 0; i < inputs.length; i++) {
            const valid = inputs[i].checkValidity();
            if (!valid) {
                inputsValid = false;
                inputs[i].classList.add("invalid-input");
            } else {
                inputs[i].classList.remove("invalid-input");
            }
        }
        return inputsValid;
    }
}
</script>
<?php
require('nic/footer.php');
?>