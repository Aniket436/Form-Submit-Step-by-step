
// Form Design

initMultiStepForm();
function initMultiStepForm() {
    const progressNumber = document.querySelectorAll(".step").length;
    const slidePage = document.querySelector(".slide-page");
    const submitBtn = document.querySelector(".submit");
    const progressText = document.querySelectorAll(".step p");
    const progressCheck = document.querySelectorAll(".step .check");
    const bullet = document.querySelectorAll(".step .bullet");
    const pages = document.querySelectorAll(".page");
    const nextButtons = document.querySelectorAll(".next");
    const prevButtons = document.querySelectorAll(".prev");
    const stepsNumber = pages.length;
    if (progressNumber !== stepsNumber) {
        console.warn(
            "Error, number of steps in progress bar do not match number of pages"
        );
    }
    document.documentElement.style.setProperty("--stepNumber", stepsNumber);
    let current = 1;
    for (let i = 0; i < nextButtons.length; i++) {
        nextButtons[i].addEventListener("click", function (event) {
            event.preventDefault();

            inputsValid = validateInputs(this);
            // inputsValid = true;

            if (inputsValid) {
                slidePage.style.marginLeft = `-${
                    (100 / stepsNumber) * current
                }%`;
                bullet[current - 1].classList.add("active");
                progressCheck[current - 1].classList.add("active");
                progressText[current - 1].classList.add("active");
                current += 1;
            }
        });
    }
    for (let i = 0; i < prevButtons.length; i++) {
        prevButtons[i].addEventListener("click", function (event) {
            event.preventDefault();
            slidePage.style.marginLeft = `-${
                (100 / stepsNumber) * (current - 2)
            }%`;
            bullet[current - 2].classList.remove("active");
            progressCheck[current - 2].classList.remove("active");
            progressText[current - 2].classList.remove("active");
            current -= 1;
        });
    }
    submitBtn.addEventListener("click", function () {
        bullet[current - 1].classList.add("active");
        progressCheck[current - 1].classList.add("active");
        progressText[current - 1].classList.add("active");
        current += 1;
        setTimeout(function () {
            alert("Your Form Successfully Signed up");
            location.reload();
        }, 800);
    });

    function validateInputs(ths) {
        let inputsValid = true;

        const inputs =
            ths.parentElement.parentElement.querySelectorAll("input");
        for (let i = 0; i < inputs.length; i++) {
            const valid = inputs[i].checkValidity();
            if (!valid) {
                inputsValid = false;
                inputs[i].classList.add("invalid-input");
            } else {
                inputs[i].classList.remove("invalid-input");
            }
        }
        return inputsValid;
    }
}


// Fetch Catagery

let btn = document.getElementById('getSelectedCource');
	btn.addEventListener('click', () => {
	let rates = document.getElementsByName('category');
	rates.forEach((rate) => {
		if (rate.checked) {
			var selectItum = rate.value;
			
			if(selectItum == "Online Master's Programs"){
				var contentData = '<div class="form-check" style="display:unset;"><input class="form-check-input d-none category" type="radio" value="MBA" name="cource" id="csRadios1" required=""><label class="form-check-label" for="csRadios1">MBA</label></div><div class="form-check" style="display:unset;"><input class="form-check-input d-none category" type="radio" value="MCA" name="cource" id="csRadios2" required=""><label class="form-check-label" for="csRadios2">MCA</label></div><div class="form-check" style="display:unset;"><input class="form-check-input d-none category" type="radio" value="M.Com" name="cource" id="csRadios3" required=""><label class="form-check-label" for="csRadios3">M.Com</label></div><br/><div class="form-check" style="display:unset;"><input class="form-check-input d-none category" type="radio" value="MA" name="cource" id="csRadios4" required=""><label class="form-check-label" for="csRadios4">MA</label></div><div class="form-check" style="display:unset;"><input class="form-check-input d-none category" type="radio" value="M.Tech" name="cource" id="csRadios5" required=""><label class="form-check-label" for="csRadios5">M.Tech</label></div><div class="form-check" style="display:unset;"><input class="form-check-input d-none category" type="radio" value="M.sc" name="cource" id="csRadios6" required=""><label class="form-check-label" for="csRadios6">M.sc</label></div><div class="form-check" style="display:unset;"><input class="form-check-input d-none category" type="radio" value="Executive MBA 1 Year" name="cource" id="csRadios7" required=""><label class="form-check-label" for="csRadios7">Executive MBA (1 Year)</label></div>';
				$('#selectedCource').html(contentData);
			}
			else if(selectItum == "Online Bachelors Programs"){
				var contentData = '<div class="form-check" style="display:unset;"><input class="form-check-input d-none category" type="radio" value="BCA" name="cource" id="csRadios1" required=""><label class="form-check-label" for="csRadios1">BCA</label></div><div class="form-check" style="display:unset;"><input class="form-check-input d-none category" type="radio" value="BBA" name="cource" id="csRadios2" required=""><label class="form-check-label" for="csRadios2">BBA</label></div><div class="form-check" style="display:unset;"><input class="form-check-input d-none category" type="radio" value="B Tech" name="cource" id="csRadios3" required=""><label class="form-check-label" for="csRadios3">B Tech</label></div>';
				$('#selectedCource').html(contentData);
			}
			else if(selectItum == "Online Diploma Certificate Programs"){
				var contentData = '<div class="form-check" style="display:unset;"><input class="form-check-input d-none category" type="radio" value="Diploma" name="cource" id="csRadios1" required=""><label class="form-check-label" for="csRadios1">Diploma</label></div><div class="form-check" style="display:unset;"><input class="form-check-input d-none category" type="radio" value="Certificate" name="cource" id="csRadios2" required=""><label class="form-check-label" for="csRadios2">Certificate</label></div><div class="form-check" style="display:unset;"><input class="form-check-input d-none category" type="radio" value="CMS & ED" name="cource" id="csRadios3" required=""><label class="form-check-label" for="csRadios3">CMS & ED</label></div>';
				$('#selectedCource').html(contentData);
			}
			else if(selectItum == "Study Abroad"){
				var contentData = '<div class="form-check" style="display:unset;"><input class="form-check-input d-none category" type="radio" value="Master Degree" name="cource" id="csRadios1" required=""><label class="form-check-label" for="csRadios1">Master Degree</label></div><div class="form-check" style="display:unset;"><input class="form-check-input d-none category" type="radio" value="BCA In USA" name="cource" id="csRadios2" required=""><label class="form-check-label" for="csRadios2">BCA In USA</label></div><div class="form-check" style="display:unset;"><input class="form-check-input d-none category" type="radio" value="BBA In UK" name="cource" id="csRadios3" required=""><label class="form-check-label" for="csRadios3">BBA In UK</label></div>';
				$('#selectedCource').html(contentData);
			}
		}
	});
});

// Submit FAQ form 

function getaskQuestions(){
	var userQustions = $("#askyourqustions").val();
	$.ajax({
		type:"POST",
		url:"save-form.php",
		data:{userqustion:userQustions},
		success: function(responce){
			if(responce=="success")
			{
				window.location.reload(true);
			}else{	
				$("#errorMessage").html("<span style='color:red;'>Try again next time.</span>");
			}
		}
	})
}