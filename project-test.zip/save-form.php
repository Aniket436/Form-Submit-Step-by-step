<?php
include('nic/config_db.php');

if(isset($_POST['userqustion'])){
	
	$querys = "INSERT INTO ask_questions(questions) VALUES ('".$_POST['userqustion']."')";
	
	if(mysqli_query($conn, $querys)){
		
		echo "success";		
	}
}
?>